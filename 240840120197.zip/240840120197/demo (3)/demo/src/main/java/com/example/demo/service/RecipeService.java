package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Entity.Recipe;
import com.example.demo.dto.RecipeRequest;
import com.example.demo.dto.RecipeResponse;
import com.example.demo.repo.RecipeRepository;

@Service
public class RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

   
    public RecipeResponse getRecipeById(Long recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));
        return mapToResponse(recipe);
    }

  
    public RecipeResponse createRecipe(RecipeRequest recipeRequest) {
        Recipe recipe = new Recipe();
        recipe.setTitle(recipeRequest.getTitle());
        recipe.setDescription(recipeRequest.getDescription());
        recipe.setIngredients(recipeRequest.getIngredients());
        recipe.setInstructions(recipeRequest.getInstructions());
        recipe.setDifficultyLevel(recipeRequest.getDifficultyLevel());
        recipe.setCuisineType(recipeRequest.getCuisineType());
        recipe.setAuthor(recipeRequest.getAuthor());

        Recipe savedRecipe = recipeRepository.save(recipe);
        return mapToResponse(savedRecipe);
    }

   
    public RecipeResponse updateRecipe(Long recipeId, RecipeRequest recipeRequest) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));

        recipe.setTitle(recipeRequest.getTitle());
        recipe.setDescription(recipeRequest.getDescription());
        recipe.setIngredients(recipeRequest.getIngredients());
        recipe.setInstructions(recipeRequest.getInstructions());
        recipe.setDifficultyLevel(recipeRequest.getDifficultyLevel());
        recipe.setCuisineType(recipeRequest.getCuisineType());
        recipe.setAuthor(recipeRequest.getAuthor());

        Recipe updatedRecipe = recipeRepository.save(recipe);
        return mapToResponse(updatedRecipe);
    }

  
    public void deleteRecipe(Long recipeId) {
        recipeRepository.deleteById(recipeId);
    }

 
    private RecipeResponse mapToResponse(Recipe recipe) {
        RecipeResponse response = new RecipeResponse();
        response.setRecipeId(recipe.getRecipeId());
        response.setTitle(recipe.getTitle());
        response.setDescription(recipe.getDescription());
        response.setIngredients(recipe.getIngredients());
        response.setInstructions(recipe.getInstructions());
        response.setDifficultyLevel(recipe.getDifficultyLevel());
        response.setCuisineType(recipe.getCuisineType());
        response.setAuthor(recipe.getAuthor());
        response.setCreationDate(recipe.getCreationDate());
        return response;
    }
}
