package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.dto.RecipeRequest;
import com.example.demo.dto.RecipeResponse;
import com.example.demo.service.RecipeService;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @GetMapping("/{recipeId}")
    public ResponseEntity<RecipeResponse> getRecipeById(@PathVariable Long recipeId) {
        RecipeResponse response = recipeService.getRecipeById(recipeId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

  
    @PostMapping
    public ResponseEntity<RecipeResponse> createRecipe(@RequestBody RecipeRequest recipeRequest) {
        RecipeResponse response = recipeService.createRecipe(recipeRequest);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    
    @PutMapping("/{recipeId}")
    public ResponseEntity<RecipeResponse> updateRecipe(
            @PathVariable Long recipeId,
            @RequestBody RecipeRequest recipeRequest) {
        RecipeResponse response = recipeService.updateRecipe(recipeId, recipeRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

   
    @DeleteMapping("/{recipeId}")
    public ResponseEntity<Void> deleteRecipe(@PathVariable Long recipeId) {
        recipeService.deleteRecipe(recipeId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}